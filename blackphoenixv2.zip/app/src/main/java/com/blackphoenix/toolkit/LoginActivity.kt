package com.blackphoenix.toolkit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.blackphoenix.toolkit.utils.VPSConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var tvStatus: TextView
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        tvStatus = findViewById(R.id.tvStatus)
        btnLogin = findViewById(R.id.btnLogin)

        etUsername.setText("Arzify")
        etPassword.setText("arz666")

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()
            if (username.isEmpty() || password.isEmpty()) {
                tvStatus.text = "✖ FILL ALL FIELDS"
                return@setOnClickListener
            }
            loginToVPS(username, password)
        }
    }

    private fun loginToVPS(username: String, password: String) {
        tvStatus.text = "⏳ LOGGING IN..."
        val client = OkHttpClient()
        val json = JSONObject()
        json.put("username", username)
        json.put("password", password)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            json.toString()
        )

        val request = Request.Builder()
            .url(VPSConfig.VPS_URL + VPSConfig.LOGIN_ENDPOINT)
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    tvStatus.text = "❌ GAGAL KONEK KE SERVER"
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            val role = obj.getString("role")
                            tvStatus.text = "● LOGIN SUCCESS: $role"
                            val intent = Intent(this@LoginActivity, SplashActivity::class.java)
                            intent.putExtra("USERNAME", username)
                            intent.putExtra("ROLE", role)
                            startActivity(intent)
                            finish()
                        } else {
                            tvStatus.text = "✖ ${obj.getString("message")}"
                        }
                    } catch (e: Exception) {
                        tvStatus.text = "❌ ERROR: ${e.message}"
                    }
                }
            }
        })
    }
}