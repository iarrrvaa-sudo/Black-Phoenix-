package com.blackphoenix.toolkit

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.blackphoenix.toolkit.fragments.*

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView
    private var username: String = ""
    private var role: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        username = intent.getStringExtra("USERNAME") ?: "Arzify"
        role = intent.getStringExtra("ROLE") ?: "TK"

        val ivLogoHeader = findViewById<android.widget.ImageView>(R.id.ivLogoHeader)
        Glide.with(this)
            .load("https://github.com/iarrrvaa-sudo/Black-Phoenix-/raw/refs/heads/main/66159-removebg-preview.png")
            .into(ivLogoHeader)

        val tvAvatar = findViewById<TextView>(R.id.tvAvatar)
        tvAvatar.text = username.take(1).toUpperCase()
        tvAvatar.setOnClickListener { }

        bottomNav = findViewById(R.id.bottomNav)
        loadFragment(DashboardFragment(), false)

        bottomNav.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navDashboard -> {
                    loadFragment(DashboardFragment(), false)
                    true
                }
                R.id.navTools -> {
                    loadFragment(ToolsFragment(), false)
                    true
                }
                R.id.navHistory -> {
                    loadFragment(HistoryFragment(), false)
                    true
                }
                R.id.navSettings -> {
                    loadFragment(SettingsFragment(), false)
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment, addToBackStack: Boolean) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .apply { if (addToBackStack) addToBackStack(null) }
            .commit()
    }
}