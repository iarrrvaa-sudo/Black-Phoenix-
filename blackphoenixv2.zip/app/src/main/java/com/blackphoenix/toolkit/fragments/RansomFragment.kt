package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R

class RansomFragment : Fragment() {

    private lateinit var btnEncrypt: Button
    private lateinit var btnDecrypt: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvRansomId: TextView
    private lateinit var tvKey: TextView
    private lateinit var progressBar: ProgressBar

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_ransom, container, false)

        btnEncrypt = view.findViewById(R.id.btnEncrypt)
        btnDecrypt = view.findViewById(R.id.btnDecrypt)
        btnStop = view.findViewById(R.id.btnStop)
        tvStatus = view.findViewById(R.id.tvStatus)
        tvRansomId = view.findViewById(R.id.tvRansomId)
        tvKey = view.findViewById(R.id.tvKey)
        progressBar = view.findViewById(R.id.progressBar)

        btnEncrypt.setOnClickListener {
            tvStatus.text = "🔒 Ransomware aktif! File dienkripsi."
            tvStatus.setTextColor(0xffff4444)
            progressBar.progress = 100
        }

        btnDecrypt.setOnClickListener {
            tvStatus.text = "🔓 Dekripsi membutuhkan key dari server."
            tvStatus.setTextColor(0xff00ff00)
        }

        btnStop.setOnClickListener {
            tvStatus.text = "⏹️ Proses dihentikan"
            tvStatus.setTextColor(0xffff8800)
        }

        return view
    }
}