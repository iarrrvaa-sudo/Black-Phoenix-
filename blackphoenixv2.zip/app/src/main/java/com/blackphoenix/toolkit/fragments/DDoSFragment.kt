package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R

class DDoSFragment : Fragment() {

    private lateinit var inputTarget: EditText
    private lateinit var inputThreads: EditText
    private lateinit var inputDuration: EditText
    private lateinit var spinnerType: Spinner
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_ddos, container, false)

        inputTarget = view.findViewById(R.id.inputTarget)
        inputThreads = view.findViewById(R.id.inputThreads)
        inputDuration = view.findViewById(R.id.inputDuration)
        spinnerType = view.findViewById(R.id.spinnerType)
        btnStart = view.findViewById(R.id.btnStart)
        btnStop = view.findViewById(R.id.btnStop)
        tvStatus = view.findViewById(R.id.tvStatus)

        val types = arrayOf("http", "https", "syn", "udp", "icmp", "slowloris", "dns", "ntp", "http2", "smuggling")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, types)
        spinnerType.adapter = adapter

        btnStart.setOnClickListener {
            val target = inputTarget.text.toString().trim()
            if (target.isEmpty()) {
                Toast.makeText(requireContext(), "Masukkan target!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            tvStatus.text = "🔥 DDoS started on $target"
            tvStatus.setTextColor(0xffff4444)
        }

        btnStop.setOnClickListener {
            tvStatus.text = "⏹️ DDoS stopped"
            tvStatus.setTextColor(0xffff8800)
        }

        return view
    }
}