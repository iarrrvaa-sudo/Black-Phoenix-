package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R

class OSINTFragment : Fragment() {

    private lateinit var inputTarget: EditText
    private lateinit var btnLookup: Button
    private lateinit var tvResult: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_osint, container, false)

        inputTarget = view.findViewById(R.id.inputTarget)
        btnLookup = view.findViewById(R.id.btnLookup)
        tvResult = view.findViewById(R.id.tvResult)

        btnLookup.setOnClickListener {
            val target = inputTarget.text.toString().trim()
            if (target.isEmpty()) {
                Toast.makeText(requireContext(), "Masukkan target!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            tvResult.text = "🔍 Hasil OSINT untuk: $target\n\n⚠️ Fitur ini membutuhkan koneksi VPS"
        }

        return view
    }
}