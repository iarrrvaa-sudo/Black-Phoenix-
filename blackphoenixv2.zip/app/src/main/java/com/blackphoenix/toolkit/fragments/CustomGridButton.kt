package com.blackphoenix.toolkit.views

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.blackphoenix.toolkit.R

class CustomGridButton(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {

    private val iconView: ImageView
    private val labelView: TextView
    private var clickListener: OnClickListener? = null

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(8, 12, 8, 12)
        setBackgroundResource(R.drawable.bg_glass_border)
        isClickable = true
        isFocusable = true
        isSoundEffectsEnabled = false
        isHapticFeedbackEnabled = false

        iconView = ImageView(context).apply {
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setColorFilter(Color.parseColor("#C064F5"))
        }

        labelView = TextView(context).apply {
            layoutParams = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            setTextColor(Color.parseColor("#E0E0E6"))
            textSize = 11f
            gravity = Gravity.CENTER
            try {
                setTypeface(android.graphics.Typeface.createFromAsset(context.assets, "fonts/orbitron_bold.ttf"))
            } catch (e: Exception) {
                setTypeface(android.graphics.Typeface.DEFAULT_BOLD)
            }
            letterSpacing = 0.08f
            isAllCaps = true
            setPadding(0, 6, 0, 0)
        }

        addView(iconView)
        addView(labelView)

        setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    animate().scaleX(0.92f).scaleY(0.92f).alpha(0.6f).setDuration(100).start()
                    setBackgroundColor(Color.parseColor("#2A2A3A"))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(100).start()
                    setBackgroundResource(R.drawable.bg_glass_border)
                }
            }
            false
        }

        super.setOnClickListener { clickListener?.onClick(it) }
    }

    fun setIcon(resId: Int) { iconView.setImageResource(resId) }
    fun setLabel(text: String) { labelView.text = text }

    override fun setOnClickListener(l: OnClickListener?) {
        clickListener = l
    }
}