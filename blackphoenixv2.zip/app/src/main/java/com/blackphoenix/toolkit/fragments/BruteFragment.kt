package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R

class BruteFragment : Fragment() {

    private lateinit var spinnerPlatform: Spinner
    private lateinit var inputTarget: EditText
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_brute, container, false)

        spinnerPlatform = view.findViewById(R.id.spinnerPlatform)
        inputTarget = view.findViewById(R.id.inputTarget)
        btnStart = view.findViewById(R.id.btnStart)
        tvStatus = view.findViewById(R.id.tvStatus)

        val platforms = arrayOf("facebook", "instagram")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, platforms)
        spinnerPlatform.adapter = adapter

        btnStart.setOnClickListener {
            val target = inputTarget.text.toString().trim()
            if (target.isEmpty()) {
                Toast.makeText(requireContext(), "Masukkan target!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            tvStatus.text = "🔓 Brute force on ${spinnerPlatform.selectedItem.toString()}: $target"
        }

        return view
    }
}