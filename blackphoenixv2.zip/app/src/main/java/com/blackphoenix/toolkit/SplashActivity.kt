package com.blackphoenix.toolkit

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private lateinit var vvSplash: VideoView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvLoading: TextView
    private lateinit var btnSkip: TextView
    private var progress = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        vvSplash = findViewById(R.id.vvSplash)
        progressBar = findViewById(R.id.progressBar)
        tvLoading = findViewById(R.id.tvLoading)
        btnSkip = findViewById(R.id.btnSkip)

        val videoUrl = "https://github.com/iarrrvaa-sudo/Black-Phoenix-/raw/refs/heads/main/ssstik.io_1787811845550.mp4"
        vvSplash.setVideoURI(Uri.parse(videoUrl))

        vvSplash.setOnPreparedListener { mp ->
            mp.setVolume(1.0f, 1.0f)
            mp.isLooping = false
            vvSplash.start()
        }

        vvSplash.setOnCompletionListener {
            goToMain()
        }

        btnSkip.setOnClickListener {
            if (vvSplash.isPlaying) vvSplash.stopPlayback()
            goToMain()
        }

        simulateLoading()

        Handler(Looper.getMainLooper()).postDelayed({
            if (vvSplash.isPlaying) {
                goToMain()
            }
        }, 10000)
    }

    private fun simulateLoading() {
        progress = 0
        Handler(Looper.getMainLooper()).postDelayed(object : Runnable {
            override fun run() {
                if (progress < 100) {
                    progress += 5
                    progressBar.progress = progress
                    tvLoading.text = "LOADING $progress%"
                    Handler(Looper.getMainLooper()).postDelayed(this, 100)
                } else {
                    tvLoading.text = "SYSTEM READY"
                }
            }
        }, 500)
    }

    private fun goToMain() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("USERNAME", intent.getStringExtra("USERNAME") ?: "Arzify")
        intent.putExtra("ROLE", intent.getStringExtra("ROLE") ?: "TK")
        startActivity(intent)
        finish()
    }

    override fun onPause() {
        super.onPause()
        if (vvSplash.isPlaying) vvSplash.pause()
    }

    override fun onResume() {
        super.onResume()
        if (!vvSplash.isPlaying) vvSplash.start()
    }
}