package com.blackphoenix.toolkit

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.blackphoenix.toolkit.fragments.*

class MainActivity : AppCompatActivity() {

    private lateinit var tvAvatar: TextView
    private lateinit var ivLogoHeader: ImageView
    private var username: String = ""
    private var role: String = ""

    private lateinit var navDashboard: ImageButton
    private lateinit var navTools: ImageButton
    private lateinit var navHistory: ImageButton
    private lateinit var navSettings: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableImmersiveMode()

        username = intent.getStringExtra("USERNAME") ?: "Arzify"
        role = intent.getStringExtra("ROLE") ?: "TK"

        ivLogoHeader = findViewById(R.id.ivLogoHeader)
        Glide.with(this)
            .load("https://github.com/iarrrvaa-sudo/Black-Phoenix-/raw/refs/heads/main/66159-removebg-preview.png")
            .into(ivLogoHeader)

        tvAvatar = findViewById(R.id.tvAvatar)
        setAvatar(username)
        tvAvatar.setOnClickListener { showProfileDialog() }

        navDashboard = findViewById(R.id.navDashboard)
        navTools = findViewById(R.id.navTools)
        navHistory = findViewById(R.id.navHistory)
        navSettings = findViewById(R.id.navSettings)

        loadFragment(DashboardFragment(), false)
        setNavActive(navDashboard)

        navDashboard.setOnClickListener {
            loadFragment(DashboardFragment(), false)
            setNavActive(navDashboard)
        }

        navTools.setOnClickListener {
            val toolsFragment = ToolsFragment()
            toolsFragment.setToolsClickListener { position, title ->
                loadFeatureFragment(position, title)
            }
            loadFragment(toolsFragment, false)
            setNavActive(navTools)
        }

        navHistory.setOnClickListener {
            loadFragment(HistoryFragment(), false)
            setNavActive(navHistory)
        }

        navSettings.setOnClickListener {
            loadFragment(SettingsFragment(), false)
            setNavActive(navSettings)
        }
    }

    private fun setAvatar(name: String) {
        val initial = if (name.isNotEmpty()) name.substring(0, 1).toUpperCase() else "U"
        tvAvatar.text = initial
        tvAvatar.setBackgroundColor(getColorFromName(name))
    }

    private fun getColorFromName(name: String): Int {
        val hash = name.hashCode()
        val colors = intArrayOf(
            Color.parseColor("#ff4444"),
            Color.parseColor("#44ff44"),
            Color.parseColor("#4444ff"),
            Color.parseColor("#ffff44"),
            Color.parseColor("#ff44ff"),
            Color.parseColor("#44ffff"),
            Color.parseColor("#ff8800"),
            Color.parseColor("#8800ff"),
            Color.parseColor("#00ff88")
        )
        return colors[Math.abs(hash) % colors.size]
    }

    private fun showProfileDialog() {
        // nanti kita isi dengan dialog profil
    }

    private fun loadFragment(fragment: Fragment, addToBackStack: Boolean) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .apply { if (addToBackStack) addToBackStack(null) }
            .commit()
    }

    private fun loadFeatureFragment(position: Int, title: String) {
        val fragment = when (position) {
            0 -> DDoSFragment()
            1 -> OSINTFragment()
            2 -> RansomFragment()
            3 -> BruteFragment()
            4 -> MalwareFragment()
            else -> DashboardFragment()
        }
        val args = Bundle()
        args.putString("ROLE", role)
        args.putString("TITLE", title)
        fragment.arguments = args
        loadFragment(fragment, true)
    }

    private fun setNavActive(active: ImageButton) {
        val inactive = Color.parseColor("#666666")
        val activeColor = Color.parseColor("#ff4444")
        navDashboard.setColorFilter(inactive)
        navTools.setColorFilter(inactive)
        navHistory.setColorFilter(inactive)
        navSettings.setColorFilter(inactive)
        active.setColorFilter(activeColor)
    }

    private fun enableImmersiveMode() {
        val decorView = window.decorView
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val controller = window.insetsController
            controller?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            controller?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
    }
}