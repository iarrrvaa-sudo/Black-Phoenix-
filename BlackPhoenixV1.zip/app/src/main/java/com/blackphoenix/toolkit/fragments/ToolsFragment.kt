package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import com.blackphoenix.toolkit.views.CustomGridButton

class ToolsFragment : Fragment() {

    private var listener: ToolsClickListener? = null

    interface ToolsClickListener {
        fun onToolClick(position: Int, title: String)
    }

    fun setToolsClickListener(listener: ToolsClickListener) {
        this.listener = listener
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_tools, container, false)
        val grid = view.findViewById<GridLayout>(R.id.gridTools)

        val icons = intArrayOf(
            R.drawable.ic_ddos,
            R.drawable.ic_osint,
            R.drawable.ic_ransom,
            R.drawable.ic_brute,
            R.drawable.ic_malware
        )

        val labels = arrayOf("DDOS", "OSINT", "RANSOMWARE", "BRUTE FORCE", "MALWARE")
        val indexes = intArrayOf(0, 1, 2, 3, 4)

        for (i in icons.indices) {
            val pos = indexes[i]
            val label = labels[i]

            val button = CustomGridButton(requireContext())
            button.setIcon(icons[i])
            button.setLabel(label)

            val params = GridLayout.LayoutParams()
            params.width = 0
            params.height = GridLayout.LayoutParams.WRAP_CONTENT
            params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            params.setMargins(6, 6, 6, 6)
            button.layoutParams = params

            button.setOnClickListener {
                listener?.onToolClick(pos, label)
            }

            grid.addView(button)
        }

        return view
    }
}