package com.blackphoenix.toolkit

import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    private lateinit var vvSplash: VideoView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvLoading: TextView
    private lateinit var btnSkip: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var progress = 0
    private var isSkipped = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        enableImmersiveMode()

        vvSplash = findViewById(R.id.vvSplash)
        progressBar = findViewById(R.id.progressBar)
        tvLoading = findViewById(R.id.tvLoading)
        btnSkip = findViewById(R.id.btnSkip)

        // Video autoplay
        val videoUrl = "https://github.com/iarrrvaa-sudo/Black-Phoenix-/raw/refs/heads/main/ssstik.io_1787811845550.mp4"
        vvSplash.setVideoURI(Uri.parse(videoUrl))

        vvSplash.setOnPreparedListener { mp ->
            mp.setVolume(1.0f, 1.0f)
            mp.isLooping = false
            vvSplash.start()
        }

        vvSplash.setOnCompletionListener {
            if (!isSkipped) goToDashboard()
        }

        vvSplash.setOnErrorListener { _, _, _ ->
            goToDashboard()
            true
        }

        btnSkip.setOnClickListener {
            isSkipped = true
            if (vvSplash.isPlaying) vvSplash.stopPlayback()
            goToDashboard()
        }

        simulateLoading()

        // Fallback timeout 10 detik
        Handler(Looper.getMainLooper()).postDelayed({
            if (!isSkipped && vvSplash.isPlaying) {
                goToDashboard()
            }
        }, 10000)
    }

    private fun simulateLoading() {
        progress = 0
        progressBar.progress = 0

        handler.postDelayed(object : Runnable {
            override fun run() {
                if (progress < 100) {
                    progress += 5
                    progressBar.progress = progress
                    tvLoading.text = "LOADING $progress%"
                    handler.postDelayed(this, 100)
                } else {
                    tvLoading.text = "SYSTEM READY"
                }
            }
        }, 500)
    }

    private fun goToDashboard() {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("USERNAME", intent.getStringExtra("USERNAME") ?: "Arzify")
        intent.putExtra("ROLE", intent.getStringExtra("ROLE") ?: "TK")
        startActivity(intent)
        finish()
    }

    private fun enableImmersiveMode() {
        val decorView = window.decorView
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val controller = window.insetsController
            controller?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            controller?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
    }

    override fun onPause() {
        super.onPause()
        if (vvSplash.isPlaying) vvSplash.pause()
    }

    override fun onResume() {
        super.onResume()
        if (!vvSplash.isPlaying) vvSplash.start()
    }
}