package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R

class SettingsFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)
        val tvSettings = view.findViewById<TextView>(R.id.tvSettings)
        tvSettings.text = "⚙ Pengaturan\n\n• Dark Mode: Aktif\n• Notifikasi: Aktif\n• Logout: klik profil"
        return view
    }
}