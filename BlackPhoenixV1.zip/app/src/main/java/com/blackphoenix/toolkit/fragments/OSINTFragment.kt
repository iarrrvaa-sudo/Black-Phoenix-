package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import com.blackphoenix.toolkit.utils.VPSConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class OSINTFragment : Fragment() {

    private lateinit var inputTarget: EditText
    private lateinit var btnLookup: Button
    private lateinit var tvResult: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_osint, container, false)

        inputTarget = view.findViewById(R.id.inputTarget)
        btnLookup = view.findViewById(R.id.btnLookup)
        tvResult = view.findViewById(R.id.tvResult)

        btnLookup.setOnClickListener { startOSINT() }

        return view
    }

    private fun startOSINT() {
        val target = inputTarget.text.toString().trim()
        if (target.isEmpty()) {
            Toast.makeText(requireContext(), "Masukkan domain / IP / email!", Toast.LENGTH_SHORT).show()
            return
        }

        tvResult.text = "⏳ Mencari informasi..."
        tvResult.setTextColor(0xffff8800)

        val client = OkHttpClient()
        val json = JSONObject()
        json.put("api_key", VPSConfig.API_KEY)
        json.put("target", target)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            json.toString()
        )

        val request = Request.Builder()
            .url("${VPSConfig.VPS_URL}/api/osint")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    tvResult.text = "❌ Gagal konek ke VPS"
                    tvResult.setTextColor(0xffff4444)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                requireActivity().runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            val result = obj.getJSONObject("result")
                            val text = """
                                📋 HASIL OSINT
                                ═══════════════════
                                Whois: ${result.optString("whois")}
                                DNS: ${result.optString("dns")}
                                Geolokasi: ${result.optString("geolocation")}
                                Subdomain: ${result.optJSONArray("subdomains")?.joinToString() ?: "-"}
                            """.trimIndent()
                            tvResult.text = text
                            tvResult.setTextColor(0xff00ff00)
                        } else {
                            tvResult.text = "❌ ${obj.getString("message")}"
                            tvResult.setTextColor(0xffff4444)
                        }
                    } catch (e: Exception) {
                        tvResult.text = "❌ Error: ${e.message}"
                        tvResult.setTextColor(0xffff4444)
                    }
                }
            }
        })
    }
}