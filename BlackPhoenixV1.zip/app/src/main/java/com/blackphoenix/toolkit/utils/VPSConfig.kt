package com.blackphoenix.toolkit.utils

object VPSConfig {
    const val VPS_URL = "http://43.129.52.170:8080"
    const val API_KEY = "blackphoenix2026"
}