package com.blackphoenix.toolkit.fragments

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class DashboardFragment : Fragment() {

    private lateinit var tvWeather: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvHumidity: TextView
    private lateinit var tvClock: TextView
    private lateinit var tvPowered: TextView
    private lateinit var ivWeatherIcon: ImageView
    private val handler = Handler(Looper.getMainLooper())
    private var clockRunnable: Runnable? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        tvWeather = view.findViewById(R.id.tvWeather)
        tvTemp = view.findViewById(R.id.tvTemp)
        tvHumidity = view.findViewById(R.id.tvHumidity)
        tvClock = view.findViewById(R.id.tvClock)
        tvPowered = view.findViewById(R.id.tvPowered)
        ivWeatherIcon = view.findViewById(R.id.ivWeatherIcon)

        fetchWeather()
        startClock()
        tvPowered.text = "Powered By Arzify"

        return view
    }

    private fun fetchWeather() {
        val apiKey = "YOUR_OPENWEATHER_API_KEY"
        val city = "Jakarta"
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$city&appid=$apiKey&units=metric"

        Thread {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val result = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    result.append(line)
                }
                reader.close()

                val obj = JSONObject(result.toString())
                val weather = obj.getJSONArray("weather").getJSONObject(0).getString("description")
                val temp = obj.getJSONObject("main").getDouble("temp")
                val humidity = obj.getJSONObject("main").getInt("humidity")

                activity?.runOnUiThread {
                    tvWeather.text = weather
                    tvTemp.text = "${temp.toInt()}°C"
                    tvHumidity.text = "Kelembapan: $humidity%"
                    setWeatherIcon(weather)
                }
            } catch (e: Exception) {
                activity?.runOnUiThread { tvWeather.text = "Cuaca tidak tersedia" }
            }
        }.start()
    }

    private fun setWeatherIcon(weather: String) {
        val w = weather.toLowerCase()
        val res = when {
            w.contains("cerah") || w.contains("sunny") -> R.drawable.ic_sunny
            w.contains("berawan") || w.contains("cloud") -> R.drawable.ic_cloudy
            w.contains("hujan") || w.contains("rain") -> R.drawable.ic_rainy
            else -> R.drawable.ic_weather_default
        }
        ivWeatherIcon.setImageResource(res)
    }

    private fun startClock() {
        clockRunnable = object : Runnable {
            override fun run() {
                val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                tvClock.text = sdf.format(Date())
                handler.postDelayed(this, 1000)
            }
        }
        handler.post(clockRunnable!!)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        clockRunnable?.let { handler.removeCallbacks(it) }
    }
}