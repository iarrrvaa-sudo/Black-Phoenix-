package com.blackphoenix.toolkit

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var tvStatus: TextView
    private lateinit var btnLogin: Button

    companion object {
        private const val VPS_URL = "http://43.129.52.170:8080"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        enableImmersiveMode()

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        tvStatus = findViewById(R.id.tvStatus)
        btnLogin = findViewById(R.id.btnLogin)

        etUsername.setText("Arzify")
        etPassword.setText("arz666")

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                tvStatus.text = "✖ FILL ALL FIELDS"
                tvStatus.setTextColor(Color.parseColor("#ff4444"))
                return@setOnClickListener
            }

            loginToVPS(username, password)
        }
    }

    private fun loginToVPS(username: String, password: String) {
        tvStatus.text = "⏳ LOGGING IN..."
        tvStatus.setTextColor(Color.parseColor("#ff8800"))

        val client = OkHttpClient()
        val json = JSONObject()
        json.put("username", username)
        json.put("password", password)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8")!!,
            json.toString()
        )

        val request = Request.Builder()
            .url("$VPS_URL/api/login")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    tvStatus.text = "❌ GAGAL KONEK KE SERVER"
                    tvStatus.setTextColor(Color.parseColor("#ff4444"))
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            val role = obj.getString("role")
                            val expired = obj.getString("expired")

                            tvStatus.text = "● LOGIN SUCCESS: $role"
                            tvStatus.setTextColor(Color.parseColor("#00ff00"))

                            val intent = Intent(this@LoginActivity, SplashActivity::class.java)
                            intent.putExtra("USERNAME", username)
                            intent.putExtra("ROLE", role)
                            intent.putExtra("EXPIRED", expired)
                            startActivity(intent)
                            finish()
                        } else {
                            tvStatus.text = "✖ ${obj.getString("message")}"
                            tvStatus.setTextColor(Color.parseColor("#ff4444"))
                        }
                    } catch (e: Exception) {
                        tvStatus.text = "❌ ERROR: ${e.message}"
                        tvStatus.setTextColor(Color.parseColor("#ff4444"))
                    }
                }
            }
        })
    }

    private fun enableImmersiveMode() {
        val decorView = window.decorView
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val controller = window.insetsController
            controller?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
            controller?.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
    }
}